<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../model/Alumno.php';

class AlumnoController
    {

    private $db;
    private $alumno;

    public function __construct ()
        {

        $database = new Database();
        $this->db = $database->getConnection ();

        $this->alumno = new Alumno( $this->db );
        }
    }
?>
