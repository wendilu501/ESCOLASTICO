<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../model/alumno.php';
// iniciar sesión si no está iniciada (necesaria para flash messages)
if ( session_status () === PHP_SESSION_NONE )
    {
    session_start ();
    }

class AlumnoController
    {

    private $db;
    private $alumno;
    public function __construct ()
        {
        $database = new Database();
        $this->db = $database->getConnection ();
        if ( $this->db )
            {
            $this->alumno = new Alumno( $this->db );
            }
        else
            {
            $_SESSION[ 'flash' ] = [
                'type'     => 'error',
                'messages' => [ 'No se pudo conectar a la base de datos. Verifica que la base "escolasticos" exista y que MySQL esté ejecutándose.' ],
            ];
            }
        }
    // GUARDAR
    public function guardar ()
        {
        if ( ! $this->alumno )
            {
            return;
            }

        if ( $_SERVER[ 'REQUEST_METHOD' ] === 'POST' )
            {
            // validar CSRF token
            if ( ! isset ( $_POST[ 'csrf_token' ] ) || ! isset ( $_SESSION[ 'csrf_token' ] ) || ! hash_equals ( $_SESSION[ 'csrf_token' ], $_POST[ 'csrf_token' ] ) )
                {
                $_SESSION[ 'flash' ] = [ 'type' => 'error', 'messages' => [ 'Token CSRF inválido. Intenta recargar la página.' ] ];
                header ( 'Location: /ESCOLASTICO/view/alumnos/formulario.php' );
                exit;
                }

            // obtener y sanitizar mínimamente
            $idEstudiante = isset ( $_POST[ 'id_estudiante' ] ) ? trim ( $_POST[ 'id_estudiante' ] ) : '';
            $nombres      = isset ( $_POST[ 'nombres' ] ) ? trim ( $_POST[ 'nombres' ] ) : '';
            $apellidos    = isset ( $_POST[ 'apellidos' ] ) ? trim ( $_POST[ 'apellidos' ] ) : '';
            $correo       = isset ( $_POST[ 'correo' ] ) ? trim ( $_POST[ 'correo' ] ) : '';
            $telefono     = isset ( $_POST[ 'telefono' ] ) ? trim ( $_POST[ 'telefono' ] ) : '';
            $estado       = isset ( $_POST[ 'estado' ] ) ? trim ( $_POST[ 'estado' ] ) : '';

            $errors = [];
            if ( $idEstudiante === '' || ! filter_var ( $idEstudiante, FILTER_VALIDATE_INT ) ) $errors[] = 'ID Estudiante inválido.';
            if ( $nombres === '' ) $errors[] = 'Nombres es requerido.';
            if ( $apellidos === '' ) $errors[] = 'Apellidos es requerido.';
            if ( $correo === '' ) $errors[] = 'Correo es requerido.';
            if ( ! filter_var ( $correo, FILTER_VALIDATE_EMAIL ) ) $errors[] = 'Correo inválido.';
            if ( $estado === '' ) $errors[] = 'Estado es requerido.';

            if ( ! empty ( $errors ) )
                {
                $_SESSION[ 'flash' ] = [ 'type' => 'error', 'messages' => $errors ];
                header ( 'Location: /ESCOLASTICO/view/alumnos/formulario.php' );
                exit;
                }

            // asignar valores sanitizados (los parámetros preparados protegen contra inyección)
            $this->alumno->id_alumno = (int) $idEstudiante;
            $this->alumno->nombres   = htmlspecialchars ( $nombres, ENT_QUOTES, 'UTF-8' );
            $this->alumno->apellidos = htmlspecialchars ( $apellidos, ENT_QUOTES, 'UTF-8' );
            $this->alumno->correo    = htmlspecialchars ( $correo, ENT_QUOTES, 'UTF-8' );
            $this->alumno->telefono  = htmlspecialchars ( $telefono, ENT_QUOTES, 'UTF-8' );
            $this->alumno->estado    = htmlspecialchars ( $estado, ENT_QUOTES, 'UTF-8' );

            try
                {
                if ( $this->alumno->crear () )
                    {
                    $_SESSION[ 'flash' ] = [ 'type' => 'success', 'messages' => [ 'Alumno guardado correctamente.' ] ];
                    header ( 'Location: /ESCOLASTICO/view/alumnos/formulario.php' );
                    exit;
                    }
                else
                    {
                    // fallo sin excepción
                    error_log ( "[AlumnoController] Error al ejecutar crear()\n", 3, __DIR__ . '/../logs/app.log' );
                    $_SESSION[ 'flash' ] = [ 'type' => 'error', 'messages' => [ 'Error al guardar el alumno.' ] ];
                    header ( 'Location: /ESCOLASTICO/view/alumnos/formulario.php' );
                    exit;
                    }
                }
            catch ( Exception $e )
                {
                error_log ( "[AlumnoController] " . $e->getMessage () . "\n", 3, __DIR__ . '/../logs/app.log' );
                $_SESSION[ 'flash' ] = [ 'type' => 'error', 'messages' => [ 'Error interno al guardar. Revisa el log.' ] ];
                header ( 'Location: /ESCOLASTICO/view/alumnos/formulario.php' );
                exit;
                }
            }
        }
    // LISTAR
    public function listar ()
        {
        if ( ! $this->alumno )
            {
            return;
            }

        // paginación
        $perPage = 5;
        $page    = isset ( $_GET[ 'page' ] ) && filter_var ( $_GET[ 'page' ], FILTER_VALIDATE_INT ) ? (int) $_GET[ 'page' ] : 1;
        if ( $page < 1 ) $page = 1;
        $offset = ( $page - 1 ) * $perPage;

        $stmt = $this->alumno->leer ( $perPage, $offset );

        while ( $row = $stmt->fetch ( PDO::FETCH_ASSOC ) )
            {
            extract ( $row );

            $csrfParam = isset ( $_SESSION[ 'csrf_token' ] ) ? urlencode ( $_SESSION[ 'csrf_token' ] ) : '';

            echo "<tr>";
            echo "<td>{$id_alumno}</td>";
            echo "<td>{$nombres}</td>";
            echo "<td>{$apellidos}</td>";
            echo "<td>{$correo}</td>";
            echo "<td>{$telefono}</td>";
            echo "<td>{$estado}</td>";
            echo "<td>
                    <a class='table-link' href='?eliminar={$id_alumno}&csrf_token={$csrfParam}'>Eliminar</a>
                  </td>";
            echo "</tr>";
            }

        // mostrar enlaces de paginación
        $total      = $this->alumno->contar ();
        $totalPages = (int) ceil ( $total / $perPage );

        if ( $totalPages > 1 )
            {
            echo "<tr><td colspan='7' style='text-align:center;'>";
            for ( $p = 1; $p <= $totalPages; $p++ )
                {
                if ( $p === $page )
                    {
                    echo " <strong>{$p}</strong> ";
                    }
                else
                    {
                    echo " <a href='?page={$p}'>{$p}</a> ";
                    }
                }
            echo "</td></tr>";
            }
        }
    // ELIMINAR
    public function eliminar ()
        {
        if ( ! $this->alumno )
            {
            return;
            }

        if ( isset ( $_GET[ 'eliminar' ] ) )
            {
            // validar CSRF token en GET
            if ( ! isset ( $_GET[ 'csrf_token' ] ) || ! isset ( $_SESSION[ 'csrf_token' ] ) || ! hash_equals ( $_SESSION[ 'csrf_token' ], $_GET[ 'csrf_token' ] ) )
                {
                $_SESSION[ 'flash' ] = [ 'type' => 'error', 'messages' => [ 'Token CSRF inválido para eliminar.' ] ];
                header ( 'Location: /ESCOLASTICO/view/alumnos/formulario.php' );
                exit;
                }

            $id = $_GET[ 'eliminar' ];
            if ( ! filter_var ( $id, FILTER_VALIDATE_INT ) )
                {
                $_SESSION[ 'flash' ] = [ 'type' => 'error', 'messages' => [ 'ID inválido para eliminar.' ] ];
                header ( 'Location: /ESCOLASTICO/view/alumnos/formulario.php' );
                exit;
                }

            $this->alumno->id_alumno = (int) $id;

            try
                {
                if ( $this->alumno->eliminar () )
                    {
                    $_SESSION[ 'flash' ] = [ 'type' => 'success', 'messages' => [ 'Alumno eliminado correctamente.' ] ];
                    header ( 'Location: /ESCOLASTICO/view/alumnos/formulario.php' );
                    exit;
                    }
                }
            catch ( Exception $e )
                {
                error_log ( "[AlumnoController] " . $e->getMessage () . "\n", 3, __DIR__ . '/../logs/app.log' );
                $_SESSION[ 'flash' ] = [ 'type' => 'error', 'messages' => [ 'Error interno al eliminar. Revisa el log.' ] ];
                header ( 'Location: /ESCOLASTICO/view/alumnos/formulario.php' );
                exit;
                }
            }
        }
    }
?>
