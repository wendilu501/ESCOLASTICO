<?php

require_once "../model/Notas.php";

class NotasController
    {

    private $modelo;

    public function __construct ()
        {

        $this->modelo = new Notas();
        }

    // GUARDAR
    public function guardar ()
        {

        if ( $_POST )
            {

            $this->modelo->crear (
                $_POST[ 'materia' ],
                $_POST[ 'nota1' ],
                $_POST[ 'nota2' ],
                $_POST[ 'nota3' ],
                $_POST[ 'id_alumno' ],
            );

            header ( "Location: ../view/notas/notas.php" );
            }
        }

    // ELIMINAR
    public function eliminar ()
        {

        if ( isset ( $_GET[ 'id' ] ) )
            {

            $this->modelo->eliminar ( $_GET[ 'id' ] );

            header ( "Location: ../view/notas/notas.php" );
            }
        }
    }

$controller = new NotasController();

if ( isset ( $_GET[ 'accion' ] ) )
    {

    if ( $_GET[ 'accion' ] == "guardar" )
        {

        $controller->guardar ();
        }

    if ( $_GET[ 'accion' ] == "eliminar" )
        {

        $controller->eliminar ();
        }
    }
?>
