<?php

require_once '../model/asistencia.php';

$asistencia = new Asistencia();

if ( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' )
    {

    $materia       = $_POST[ 'materia' ];
    $creditos      = $_POST[ 'creditos' ];
    $horas_credito = $_POST[ 'horas_credito' ];
    $numero_faltas = $_POST[ 'numero_faltas' ];

    $horas_faltas = $numero_faltas * 2;

    $totalHoras = $creditos * $horas_credito;

    $porcentaje_inasistencia = ( $horas_faltas / $totalHoras ) * 100;
    $porcentaje_asistencia   = 100 - $porcentaje_inasistencia;

    $datos = [
        'materia'                 => $materia,
        'creditos'                => $creditos,
        'horas_credito'           => $horas_credito,
        'numero_faltas'           => $numero_faltas,
        'horas_faltas'            => $horas_faltas,
        'porcentaje_asistencia'   => round ( $porcentaje_asistencia, 2 ),
        'porcentaje_inasistencia' => round ( $porcentaje_inasistencia, 2 ),
        'id_alumno'               => $_POST[ 'id_alumno' ],
    ];

    $asistencia->guardar ( $datos );

    header ( "Location: ../view/asistencia/Asistencia.php" );
    }

if ( isset ( $_GET[ 'eliminar' ] ) )
    {
    $asistencia->eliminar ( $_GET[ 'eliminar' ] );

    header ( "Location: ../view/asistencia/Asistencia.php" );
    }
