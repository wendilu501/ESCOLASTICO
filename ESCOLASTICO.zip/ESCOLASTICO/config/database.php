<?php
class Database
    {
    private $host     = "localhost";
    private $db_name  = "escolasticos";
    private $username = "root";
    private $password = "";
    public  $conn;
    public function getConnection ()
        {
        $this->conn = null;

        try
            {
            $options = array(
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => FALSE,
            );

            $this->conn = new PDO(
                "mysql:host={$this->host};dbname={$this->db_name};charset=utf8",
                $this->username,
                $this->password,
                $options,
            );

            }
        catch ( PDOException $exception )
            {
            // registrar error en log y devolver null
            error_log ( "[Database] " . $exception->getMessage () . "\n", 3, __DIR__ . '/../logs/app.log' );
            echo "Error de conexión. Comprueba la configuración de la base de datos.";
            }

        return $this->conn;
        }
    }
?>
