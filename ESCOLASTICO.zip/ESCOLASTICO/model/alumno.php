<?php
class Alumno
    {

    private $conn;
    private $table = "alumnos";

    public $id;
    public $nombre;
    public $apellido;
    public $edad;
    public $curso;
    public function __construct ( $db )
        {
        $this->conn = $db;
        }

    // INSERTAR
    public function crear ()
        {

        $query = "INSERT INTO " . $this->table . "
                SET
                    nombre = :nombre,
                    apellido = :apellido,
                    edad = :edad,
                    curso = :curso";
        $stmt  = $this->conn->prepare ( $query );

        $stmt->bindParam ( ':nombre', $this->nombre );
        $stmt->bindParam ( ':apellido', $this->apellido );
        $stmt->bindParam ( ':edad', $this->edad );
        $stmt->bindParam ( ':curso', $this->curso );

        if ( $stmt->execute () )
            {
            return TRUE;
            }

        return FALSE;
        }
    // MOSTRAR
    public function leer ()
        {

        $query = "SELECT * FROM " . $this->table . " ORDER BY id DESC";

        $stmt = $this->conn->prepare ( $query );
        $stmt->execute ();

        return $stmt;
        }
    // ELIMINAR
    public function eliminar ()
        {

        $query = "DELETE FROM " . $this->table . " WHERE id = :id";

        $stmt = $this->conn->prepare ( $query );

        $stmt->bindParam ( ':id', $this->id );

        if ( $stmt->execute () )
            {
            return TRUE;
            }

        return FALSE;
        }
    // ACTUALIZAR
    public function actualizar ()
        {

        $query = "UPDATE " . $this->table . "
                SET
                    nombre = :nombre,
                    apellido = :apellido,
                    edad = :edad,
                    curso = :curso
                WHERE
                    id = :id";

        $stmt = $this->conn->prepare ( $query );

        $stmt->bindParam ( ':nombre', $this->nombre );
        $stmt->bindParam ( ':apellido', $this->apellido );
        $stmt->bindParam ( ':edad', $this->edad );
        $stmt->bindParam ( ':curso', $this->curso );
        $stmt->bindParam ( ':id', $this->id );
        if ( $stmt->execute () )
            {
            return TRUE;
            }

        return FALSE;
        }
    }
?>
