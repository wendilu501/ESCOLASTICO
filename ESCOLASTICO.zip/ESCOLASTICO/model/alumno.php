<?php
class Alumno
    {

    private $conn;
    private $table = "alumnos";

    public $id_alumno;
    public $nombres;
    public $apellidos;
    public $correo;
    public $telefono;
    public $estado;
    public function __construct ( $db )
        {
        $this->conn = $db;
        }

    // INSERTAR
    public function crear ()
        {

        $query = "INSERT INTO " . $this->table . "
                SET
                    id_alumno = :id_alumno,
                    nombres = :nombres,
                    apellidos = :apellidos,
                    correo = :correo,
                    telefono = :telefono,
                    estado = :estado";
        $stmt  = $this->conn->prepare ( $query );

        $stmt->bindParam ( ':id_alumno', $this->id_alumno );
        $stmt->bindParam ( ':nombres', $this->nombres );
        $stmt->bindParam ( ':apellidos', $this->apellidos );
        $stmt->bindParam ( ':correo', $this->correo );
        $stmt->bindParam ( ':telefono', $this->telefono );
        $stmt->bindParam ( ':estado', $this->estado );

        if ( $stmt->execute () )
            {
            return TRUE;
            }

        return FALSE;
        }
    // MOSTRAR
    public function leer ( $limit = null, $offset = 0 )
        {
        $query = "SELECT * FROM " . $this->table . " ORDER BY id_alumno DESC";

        if ( $limit !== null )
            {
            $query .= " LIMIT :limit OFFSET :offset";
            $stmt   = $this->conn->prepare ( $query );
            $stmt->bindValue ( ':limit', (int) $limit, PDO::PARAM_INT );
            $stmt->bindValue ( ':offset', (int) $offset, PDO::PARAM_INT );
            $stmt->execute ();
            return $stmt;
            }

        $stmt = $this->conn->prepare ( $query );
        $stmt->execute ();

        return $stmt;
        }

    // CONTAR TOTAL (para paginación)
    public function contar ()
        {
        $query = "SELECT COUNT(*) as total FROM " . $this->table;
        $stmt  = $this->conn->prepare ( $query );
        $stmt->execute ();
        $row = $stmt->fetch ( PDO::FETCH_ASSOC );
        return isset ( $row[ 'total' ] ) ? (int) $row[ 'total' ] : 0;
        }
    // ELIMINAR
    public function eliminar ()
        {

        $query = "DELETE FROM " . $this->table . " WHERE id_alumno = :id_alumno";

        $stmt = $this->conn->prepare ( $query );

        $stmt->bindParam ( ':id_alumno', $this->id_alumno );

        if ( $stmt->execute () )
            {
            return TRUE;
            }

        return FALSE;
        }
    // ACTUALIZAR
    public function actualizar ()
        {

        $query = "UPDATE " . $this->table . "
                SET
                    nombres = :nombres,
                    apellidos = :apellidos,
                    correo = :correo,
                    telefono = :telefono,
                    estado = :estado
                WHERE
                    id_alumno = :id_alumno";

        $stmt = $this->conn->prepare ( $query );

        $stmt->bindParam ( ':nombres', $this->nombres );
        $stmt->bindParam ( ':apellidos', $this->apellidos );
        $stmt->bindParam ( ':correo', $this->correo );
        $stmt->bindParam ( ':telefono', $this->telefono );
        $stmt->bindParam ( ':estado', $this->estado );
        $stmt->bindParam ( ':id_alumno', $this->id_alumno );
        if ( $stmt->execute () )
            {
            return TRUE;
            }

        return FALSE;
        }
    }
?>
