<?php

require_once __DIR__ . "/../config/database.php";

class Notas
    {

    private $conn;

    public function __construct ()
        {

        $database   = new Database();
        $this->conn = $database->getConnection ();
        }

    // INSERTAR
    public function crear ( $materia, $nota1, $nota2, $nota3, $id_alumno )
        {

        $promedio = ( $nota1 + $nota2 + $nota3 ) / 3;

        $sql = "INSERT INTO notas 
                (materia, nota1, nota2, nota3, promedio, id_alumno)
                VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = $this->conn->prepare ( $sql );

        return $stmt->execute ( [
            $materia,
            $nota1,
            $nota2,
            $nota3,
            $promedio,
            $id_alumno,
        ] );
        }

    // MOSTRAR
    public function obtenerTodos ()
        {

        $sql = "SELECT * FROM notas";

        $stmt = $this->conn->prepare ( $sql );

        $stmt->execute ();

        return $stmt->fetchAll ( PDO::FETCH_ASSOC );
        }

    // OBTENER POR ID
    public function obtenerPorId ( $id )
        {

        $sql = "SELECT * FROM notas WHERE id_nota = ?";

        $stmt = $this->conn->prepare ( $sql );

        $stmt->execute ( [ $id ] );

        return $stmt->fetch ( PDO::FETCH_ASSOC );
        }

    // ACTUALIZAR
    public function actualizar ( $id, $materia, $nota1, $nota2, $nota3, $id_alumno )
        {

        $promedio = ( $nota1 + $nota2 + $nota3 ) / 3;

        $sql = "UPDATE notas 
                SET materia = ?,
                    nota1 = ?,
                    nota2 = ?,
                    nota3 = ?,
                    promedio = ?,
                    id_alumno = ?
                WHERE id_nota = ?";

        $stmt = $this->conn->prepare ( $sql );

        return $stmt->execute ( [
            $materia,
            $nota1,
            $nota2,
            $nota3,
            $promedio,
            $id_alumno,
            $id,
        ] );
        }

    // ELIMINAR
    public function eliminar ( $id )
        {

        $sql = "DELETE FROM notas WHERE id_nota = ?";

        $stmt = $this->conn->prepare ( $sql );

        return $stmt->execute ( [ $id ] );
        }
    }
?>
