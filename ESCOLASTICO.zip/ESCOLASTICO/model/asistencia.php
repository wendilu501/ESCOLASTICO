<?php

require_once __DIR__ . '/../config/database.php';

class Asistencia
    {
    private $conn;

    public function __construct ()
        {
        $database   = new Database();
        $this->conn = $database->getConnection ();
        }

    // Guardar asistencia
    public function guardar ( $data )
        {
        $sql = "INSERT INTO asistencias (
                    materia,
                    creditos,
                    horas_credito,
                    numero_faltas,
                    horas_faltas,
                    porcentaje_asistencia,
                    porcentaje_inasistencia,
                    id_alumno
                ) VALUES (
                    :materia,
                    :creditos,
                    :horas_credito,
                    :numero_faltas,
                    :horas_faltas,
                    :porcentaje_asistencia,
                    :porcentaje_inasistencia,
                    :id_alumno
                )";

        $stmt = $this->conn->prepare ( $sql );

        return $stmt->execute ( [
            ':materia'                 => $data[ 'materia' ],
            ':creditos'                => $data[ 'creditos' ],
            ':horas_credito'           => $data[ 'horas_credito' ],
            ':numero_faltas'           => $data[ 'numero_faltas' ],
            ':horas_faltas'            => $data[ 'horas_faltas' ],
            ':porcentaje_asistencia'   => $data[ 'porcentaje_asistencia' ],
            ':porcentaje_inasistencia' => $data[ 'porcentaje_inasistencia' ],
            ':id_alumno'               => $data[ 'id_alumno' ],
        ] );
        }

    // Listar asistencias
    public function listar ()
        {
        $sql = "SELECT * FROM asistencias ORDER BY id_asistencia DESC";

        $stmt = $this->conn->prepare ( $sql );
        $stmt->execute ();

        return $stmt->fetchAll ( PDO::FETCH_ASSOC );
        }

    // Buscar una asistencia por ID
    public function obtenerPorId ( $id )
        {
        $sql = "SELECT * FROM asistencias WHERE id_asistencia = :id";

        $stmt = $this->conn->prepare ( $sql );

        $stmt->execute ( [
            ':id' => $id,
        ] );

        return $stmt->fetch ( PDO::FETCH_ASSOC );
        }

    // Eliminar asistencia
    public function eliminar ( $id )
        {
        $sql = "DELETE FROM asistencias WHERE id_asistencia = :id";

        $stmt = $this->conn->prepare ( $sql );

        return $stmt->execute ( [
            ':id' => $id,
        ] );
        }

    // Actualizar asistencia
    public function actualizar ( $id, $data )
        {
        $sql = "UPDATE asistencias SET
                    materia = :materia,
                    creditos = :creditos,
                    horas_credito = :horas_credito,
                    numero_faltas = :numero_faltas,
                    horas_faltas = :horas_faltas,
                    porcentaje_asistencia = :porcentaje_asistencia,
                    porcentaje_inasistencia = :porcentaje_inasistencia,
                    id_alumno = :id_alumno
                WHERE id_asistencia = :id";

        $stmt = $this->conn->prepare ( $sql );

        return $stmt->execute ( [
            ':materia'                 => $data[ 'materia' ],
            ':creditos'                => $data[ 'creditos' ],
            ':horas_credito'           => $data[ 'horas_credito' ],
            ':numero_faltas'           => $data[ 'numero_faltas' ],
            ':horas_faltas'            => $data[ 'horas_faltas' ],
            ':porcentaje_asistencia'   => $data[ 'porcentaje_asistencia' ],
            ':porcentaje_inasistencia' => $data[ 'porcentaje_inasistencia' ],
            ':id_alumno'               => $data[ 'id_alumno' ],
            ':id'                      => $id,
        ] );
        }
    }
?>
