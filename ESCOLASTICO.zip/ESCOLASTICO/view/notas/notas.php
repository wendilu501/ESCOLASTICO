<?php

require_once "../../model/Notas.php";

$modelo = new Notas();

$notas = $modelo->obtenerTodos ();

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Sistema de Notas</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f3e8ff, #ede9fe);
            min-height: 100vh;
            padding: 30px;
            color: #2e1065;
        }

        .container {
            max-width: 1200px;
            margin: auto;
        }

        h1 {
            font-size: 42px;
            margin-bottom: 10px;
            color: #3b0764;
        }

        .subtitle {
            margin-bottom: 30px;
            color: #6b21a8;
        }

        .card {

            background: white;
            padding: 30px;
            border-radius: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            margin-bottom: 40px;
        }

        .form-grid {

            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .input-group {

            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
            font-weight: 600;
            color: #581c87;
        }

        input {

            padding: 14px;
            border-radius: 14px;
            border: 2px solid #d8b4fe;
            outline: none;
            font-size: 15px;
            transition: 0.3s;
        }

        input:focus {
            border-color: #7c3aed;
            box-shadow: 0 0 10px rgba(124, 58, 237, 0.2);
        }

        .btns {

            margin-top: 30px;
            display: flex;
            gap: 15px;
        }

        button {

            padding: 14px 25px;
            border: none;
            border-radius: 14px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-guardar {

            background: linear-gradient(135deg, #7c3aed, #5b21b6);
            color: white;
            box-shadow: 0 5px 15px rgba(124, 58, 237, 0.4);
        }

        .btn-guardar:hover {
            transform: translateY(-2px);
        }

        .btn-limpiar {

            background: white;
            border: 2px solid #d8b4fe;
            color: #581c87;
        }

        .btn-limpiar:hover {
            background: #f5f3ff;
        }

        .table-container {

            overflow-x: auto;
        }

        table {

            width: 100%;
            border-collapse: collapse;
            overflow: hidden;
            border-radius: 20px;
        }

        thead {

            background: linear-gradient(135deg, #8b5cf6, #6d28d9);
            color: white;
        }

        th,
        td {

            padding: 18px;
            text-align: center;
        }

        tbody tr {

            background: white;
            border-bottom: 1px solid #eee;
            transition: 0.3s;
        }

        tbody tr:hover {

            background: #f5f3ff;
        }

        .btn-eliminar {

            text-decoration: none;
            background: #ef4444;
            color: white;
            padding: 8px 14px;
            border-radius: 10px;
            transition: 0.3s;
        }

        .btn-eliminar:hover {

            background: #dc2626;
        }

        .promedio {

            font-weight: bold;
            color: #6d28d9;
        }
    </style>

</head>

<body>

    <div class="container">

        <h1>Registro de Notas</h1>

        <p class="subtitle">
            Administra las notas de tus estudiantes con estilo moderno 😎
        </p>

        <!-- FORMULARIO -->

        <div class="card">

            <form action="../../controller/NotasController.php?accion=guardar" method="POST">

                <div class="form-grid">

                    <div class="input-group">
                        <label>Materia</label>
                        <input type="text" name="materia" placeholder="Ej: Matemáticas" required>
                    </div>

                    <div class="input-group">
                        <label>Nota 1</label>
                        <input type="number" step="0.01" name="nota1" placeholder="0 - 10" required>
                    </div>

                    <div class="input-group">
                        <label>Nota 2</label>
                        <input type="number" step="0.01" name="nota2" placeholder="0 - 10" required>
                    </div>

                    <div class="input-group">
                        <label>Nota 3</label>
                        <input type="number" step="0.01" name="nota3" placeholder="0 - 10" required>
                    </div>

                    <div class="input-group">
                        <label>ID Alumno</label>
                        <input type="number" name="id_alumno" placeholder="ID del alumno" required>
                    </div>

                </div>

                <div class="btns">

                    <button class="btn-guardar" type="submit">
                        Guardar Nota
                    </button>

                    <button class="btn-limpiar" type="reset">
                        Limpiar
                    </button>

                </div>

            </form>

        </div>

        <!-- TABLA -->

        <h1 style="font-size:35px;">Lista de Notas</h1>

        <div class="card table-container">

            <table>

                <thead>

                    <tr>
                        <th>ID</th>
                        <th>Materia</th>
                        <th>Nota 1</th>
                        <th>Nota 2</th>
                        <th>Nota 3</th>
                        <th>Promedio</th>
                        <th>ID Alumno</th>
                        <th>Acción</th>
                    </tr>

                </thead>

                <tbody>

                    <?php foreach ( $notas as $nota ) : ?>

                        <tr>

                            <td><?= $nota[ 'id_nota' ] ?></td>

                            <td><?= $nota[ 'materia' ] ?></td>

                            <td><?= $nota[ 'nota1' ] ?></td>

                            <td><?= $nota[ 'nota2' ] ?></td>

                            <td><?= $nota[ 'nota3' ] ?></td>

                            <td class="promedio">
                                <?= number_format ( $nota[ 'promedio' ], 2 ) ?>
                            </td>

                            <td><?= $nota[ 'id_alumno' ] ?></td>

                            <td>

                                <a class="btn-eliminar"
                                    href="../../controller/NotasController.php?accion=eliminar&id=<?= $nota[ 'id_nota' ] ?>">

                                    Eliminar

                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    </div>

</body>

</html>