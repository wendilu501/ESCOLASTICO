<?php
require_once '../../controller/AlumnoController.php';

$controller = new AlumnoController();

$controller->guardar ();
$controller->eliminar ();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Escolar</title>

    <style>
        body {
            font-family: Arial;
            background: #f4f4f4;
            padding: 20px;
        }

        .container {
            width: 80%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
        }

        button {
            margin-top: 15px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
         table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        a {
            color: red;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container"> <h2>Registro de Alumnos</h2>

    <form method="POST">

        <input type="text" name="nombre" placeholder="Nombre" required>

        <input type="text" name="apellido" placeholder="Apellido" required>

        <input type="number" name="edad" placeholder="Edad" required>

        <input type="text" name="curso" placeholder="Curso" required>

        <button type="submit">Guardar</button>

    </form>
 <h2>Lista de Alumnos</h2>

    <table>

        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Edad</th>
            <th>Curso</th>
            <th>Acción</th>
        </tr>
<?php
$controller->listar ();
?>

</table>

</div>

</body>

</html>