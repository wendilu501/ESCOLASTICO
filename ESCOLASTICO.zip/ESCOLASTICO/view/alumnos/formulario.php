<?php
// iniciar sesión para flash messages
if ( session_status () === PHP_SESSION_NONE )
    {
    session_start ();
    }

// generar token CSRF si no existe
if ( ! isset ( $_SESSION[ 'csrf_token' ] ) )
    {
    $_SESSION[ 'csrf_token' ] = bin2hex ( random_bytes ( 32 ) );
    }

require_once '../../controller/AlumnoController.php';

$controller = new AlumnoController();

$controller->guardar ();
$controller->eliminar ();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Escolar</title>

    <style>
        :root {
            --bg: #f3e9ff;
            --card: #ffffff;
            --card-2: #f9f0ff;
            --border: #e1c4ff;
            --text: #2e136d;
            --text-muted: #6c4fa1;
            --primary: #7a4dff;
            --primary-dark: #5a2dcf;
            --secondary: #b294ff;
            --danger: #da4fff;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(180deg, #f4e8ff 0%, #efe0ff 100%);
            color: var(--text);
        }

        .page {
            min-height: 100vh;
            padding: 30px 20px;
            display: flex;
            justify-content: center;
        }

        .wrapper {
            width: min(1200px, 100%);
        }

        .section-title {
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--text);
            margin-bottom: 18px;
        }

        .section-title h2 {
            margin: 0;
            font-size: 1.8rem;
        }

        .card {
            background: var(--card);
            border-radius: 24px;
            box-shadow: 0 24px 50px rgba(105, 45, 140, 0.12);
            border: 1px solid rgba(122, 77, 255, 0.15);
            padding: 28px;
            margin-bottom: 24px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 18px;
            margin-top: 20px;
        }

        .input-group {
            display: flex;
            flex-direction: column;
        }

        .input-group label {
            font-size: 0.95rem;
            color: var(--text-muted);
            margin-bottom: 8px;
        }

        .input-group input,
        .input-group select {
            border: 1px solid rgba(122, 77, 255, 0.25);
            background: var(--card-2);
            border-radius: 14px;
            padding: 14px 16px;
            font-size: 0.98rem;
            color: #2d1a65;
            outline: none;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .input-group input:focus,
        .input-group select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(122, 77, 255, 0.12);
        }

        .actions {
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
            margin-top: 22px;
        }

        .btn {
            border: none;
            border-radius: 14px;
            padding: 14px 24px;
            font-size: 1rem;
            cursor: pointer;
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 14px 28px rgba(122, 77, 255, 0.25);
        }

        .btn-secondary {
            background: transparent;
            color: var(--text);
            border: 1px solid rgba(122, 77, 255, 0.25);
        }

        .btn:hover {
            transform: translateY(-1px);
        }

        .btn-primary:hover {
            box-shadow: 0 18px 30px rgba(122, 77, 255, 0.32);
        }

        .message {
            padding: 16px 18px;
            margin-top: 16px;
            border-radius: 18px;
            font-weight: 500;
            line-height: 1.5;
        }

        .message.success {
            background: #eef8ff;
            color: #25365f;
            border: 1px solid #cce5ff;
        }

        .message.error {
            background: #fff0f7;
            color: #7a1840;
            border: 1px solid #f9d6ee;
        }

        .table-card {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: transparent;
            min-width: 720px;
        }

        th,
        td {
            padding: 16px 14px;
            text-align: left;
        }

        th {
            background: linear-gradient(90deg, rgba(122, 77, 255, 0.95), rgba(169, 124, 255, 0.95));
            color: white;
            font-weight: 600;
        }

        tr {
            border-bottom: 1px solid rgba(122, 77, 255, 0.12);
        }

        tr:nth-child(even) {
            background: rgba(122, 77, 255, 0.04);
        }

        td {
            color: #4b2b86;
        }

        .table-link {
            color: var(--danger);
            font-weight: 600;
            text-decoration: none;
        }

        .table-link:hover {
            text-decoration: underline;
        }

        .pagination {
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 18px;
            padding-top: 10px;
        }

        .pagination a,
        .pagination strong {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 12px;
            text-decoration: none;
            color: var(--text);
            border: 1px solid rgba(122, 77, 255, 0.18);
            background: #fff;
        }

        .pagination strong {
            background: var(--secondary);
            border-color: transparent;
            color: #3b1368;
        }

        .pagination a:hover {
            background: rgba(122, 77, 255, 0.08);
        }

        @media (max-width: 800px) {
            .form-grid {
                grid-template-columns: 1fr;
            }

            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

    <div class="page">
        <div class="wrapper">
            <div class="section-title">
                <div>
                    <h2>Registro de Alumnos</h2>
                    <p style="margin: 8px 0 0; color: var(--text-muted);">Registra a tus estudiantes con un estilo
                        moderno.</p>
                </div>
            </div>

            <?php
            // Mostrar flash messages desde la sesión
            if ( isset ( $_SESSION[ 'flash' ] ) )
                {
                $flash = $_SESSION[ 'flash' ];
                $type  = isset ( $flash[ 'type' ] ) && $flash[ 'type' ] === 'success' ? 'success' : 'error';
                if ( isset ( $flash[ 'messages' ] ) && is_array ( $flash[ 'messages' ] ) )
                    {
                    echo "<div class='message {$type}'>";
                    foreach ( $flash[ 'messages' ] as $m )
                        {
                        echo "<div>" . htmlspecialchars ( $m ) . "</div>";
                        }
                    echo "</div>";
                    }
                unset ( $_SESSION[ 'flash' ] );
                }
            ?>

            <div class="card">
                <form method="POST">
                    <input type="hidden" name="csrf_token"
                        value="<?php echo htmlspecialchars ( $_SESSION[ 'csrf_token' ] ); ?>">

                    <div class="form-grid">
                        <div class="input-group">
                            <label for="id_estudiante">ID Estudiante</label>
                            <input id="id_estudiante" type="number" name="id_estudiante" placeholder="ID del estudiante"
                                required>
                        </div>
                        <div class="input-group">
                            <label for="nombres">Nombres</label>
                            <input id="nombres" type="text" name="nombres" placeholder="Nombre completo" required>
                        </div>
                        <div class="input-group">
                            <label for="apellidos">Apellidos</label>
                            <input id="apellidos" type="text" name="apellidos" placeholder="Apellido" required>
                        </div>
                        <div class="input-group">
                            <label for="correo">Correo</label>
                            <input id="correo" type="email" name="correo" placeholder="correo@dominio.com" required>
                        </div>
                        <div class="input-group">
                            <label for="telefono">Teléfono</label>
                            <input id="telefono" type="text" name="telefono" placeholder="Número de teléfono">
                        </div>
                        <div class="input-group">
                            <label for="estado">Estado</label>
                            <select id="estado" name="estado" required>
                                <option value="">Selecciona estado</option>
                                <option value="activo">Activo</option>
                                <option value="inactivo">Inactivo</option>
                                <option value="suspendido">Suspendido</option>
                            </select>
                        </div>
                    </div>

                    <div class="actions">
                        <button type="submit" class="btn btn-primary">Guardar Alumno</button>
                        <button type="reset" class="btn btn-secondary">Limpiar</button>
                    </div>
                </form>
            </div>

            <div class="section-title" style="margin-top: 24px;">
                <div>
                    <h2>Lista de Alumnos</h2>
                </div>
            </div>

            <div class="card table-card">
                <table>
                    <tr>
                        <th>ID Estudiante</th>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Correo</th>
                        <th>Teléfono</th>
                        <th>Estado</th>
                        <th>Acción</th>
                    </tr>
                    <?php
                    $controller->listar ();
                    ?>
                </table>
            </div>
        </div>
    </div>

</body>

</html>