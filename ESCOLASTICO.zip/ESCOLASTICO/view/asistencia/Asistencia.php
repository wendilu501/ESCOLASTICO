<?php

require_once '../../model/asistencia.php';

$model       = new Asistencia();
$asistencias = $model->listar ();

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Registro de Asistencia</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #eee7f8;
            font-family: 'Segoe UI', sans-serif;
        }

        .container-main {
            width: 90%;
            margin: auto;
            padding: 30px;
        }

        h1 {
            color: #3e0d83;
            font-weight: bold;
        }

        .card-form {
            background: white;
            border-radius: 25px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, .1);
        }

        .form-control {
            border: 2px solid #cba6ff;
            border-radius: 15px;
        }

        .btn-guardar {
            background: linear-gradient(90deg,
                    #8a4fff,
                    #6a11cb);
            color: white;
            border: none;
            border-radius: 15px;
            padding: 12px 30px;
        }

        .btn-guardar:hover {
            color: white;
        }

        .table thead {
            background: linear-gradient(90deg,
                    #8a4fff,
                    #6a11cb);
            color: white;
        }

        .table {
            border-radius: 20px;
            overflow: hidden;
        }
    </style>

</head>

<body>

    <div class="container-main">

        <h1>Registro de Asistencia 📚</h1>

        <p class="text-purple">
            Administra las asistencias de tus estudiantes
        </p>

        <div class="card-form">

            <form action="../../controller/AsistenciaController.php" method="POST">

                <div class="row">

                    <div class="col-md-3 mb-3">
                        <label>Materia</label>
                        <input type="text" name="materia" class="form-control" required>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Créditos</label>
                        <input type="number" name="creditos" class="form-control" required>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Horas Crédito</label>
                        <input type="number" name="horas_credito" class="form-control" required>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Número Faltas</label>
                        <input type="number" name="numero_faltas" class="form-control" required>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label>ID Alumno</label>
                        <input type="number" name="id_alumno" class="form-control" required>
                    </div>

                </div>

                <button class="btn btn-guardar">
                    Guardar Asistencia
                </button>

            </form>

        </div>

        <br><br>

        <h2 style="color:#3e0d83;">
            Lista de Asistencias
        </h2>

        <div class="card-form">

            <table class="table table-hover">

                <thead>

                    <tr>
                        <th>ID</th>
                        <th>Materia</th>
                        <th>Créditos</th>
                        <th>Horas Crédito</th>
                        <th>Faltas</th>
                        <th>Horas Faltas</th>
                        <th>% Asistencia</th>
                        <th>% Inasistencia</th>
                        <th>ID Alumno</th>
                        <th>Acción</th>
                    </tr>

                </thead>

                <tbody>

                    <?php foreach ( $asistencias as $a ) : ?>

                        <tr>

                            <td>
                                <?= $a[ 'id_asistencia' ] ?>
                            </td>
                            <td>
                                <?= $a[ 'materia' ] ?>
                            </td>
                            <td>
                                <?= $a[ 'creditos' ] ?>
                            </td>
                            <td>
                                <?= $a[ 'horas_credito' ] ?>
                            </td>
                            <td>
                                <?= $a[ 'numero_faltas' ] ?>
                            </td>
                            <td>
                                <?= $a[ 'horas_faltas' ] ?>
                            </td>
                            <td>
                                <?= $a[ 'porcentaje_asistencia' ] ?>%
                            </td>
                            <td>
                                <?= $a[ 'porcentaje_inasistencia' ] ?>%
                            </td>
                            <td>
                                <?= $a[ 'id_alumno' ] ?>
                            </td>

                            <td>

                                <a href="../../controller/AsistenciaController.php?eliminar=<?= $a[ 'id_asistencia' ] ?>"
                                    class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar registro?')">

                                    Eliminar

                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    </div>

</body>

</html>