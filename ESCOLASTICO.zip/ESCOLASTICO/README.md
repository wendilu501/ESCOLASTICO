# ESCOLASTICO

Proyecto escolar PHP + MySQL (ejemplo simple)

Requisitos

- XAMPP o similar (Apache + PHP + MySQL)
- PHP 7.4+ (se recomienda PHP 8+)

Instalación rápida

1. Copia la carpeta `ESCOLASTICO` a `C:\xampp\htdocs\`
2. Crea la base de datos `escolastico` y la tabla `alumnos` (ejemplo):

```sql
CREATE DATABASE escolasticos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE escolasticos;

CREATE TABLE alumnos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100) NOT NULL,
  edad INT NOT NULL,
  curso VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

3. Ajusta credenciales en `config/database.php` si es necesario.
4. Inicia Apache y MySQL desde XAMPP.
5. Accede a:

```
http://localhost/ESCOLASTICO/view/alumnos/formulario.php
```

Notas

- Los errores se registran en `logs/app.log`.
- Implementé protección CSRF básica (token en sesión), validación de entradas y paginación en la lista.
- Para mejoras sugeridas: protección más completa CSRF, autenticación, interfaz mejorada.

Si necesitas que añada export CSV, edición en línea o autenticación, dímelo.
